<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>


	<h1> HELLO SAIDIL </h1>

</body>
</html><?php /**PATH C:\Users\ASUS\Documents\LARAVEL_PROJECT\app_first\resources\views/coba.blade.php ENDPATH**/ ?>